#include "game.h"

Game::Game()
{
	this->graphics = new Graphics();    
	this->isRunning = true;
	this->current_scene = SCENE_START;
	this->player_one_score = 100;
	this->player_two_score = 100;
	this->button_timer = 0;
	
	this->mainLoop();
}

int Game::getPlayerOneScore()
{
	return this->player_one_score;
}

int Game::getPlayerTwoScore()
{
	return this->player_two_score;
}

void Game::mainLoop()
{
	while(true)
	{
		this->graphics->setScores(this->player_one_score, this->player_two_score);
		this->graphics->setChoices(this->choice_one, this->choice_two);
		this->graphics->setQuestion(this->current_question);
		this->graphics->draw(this->current_scene);
		this->handleInput(this->current_scene);
		
		this->button_timer++;
		this->result_timer++;
		if(this->current_scene == SCENE_RESULT &&
			this->result_timer > 800000)
		{
			this->player_one_score = 100;
			this->player_two_score = 100;
			this->current_scene = SCENE_GAME;
			this->graphics->loadGameScene(this->current_question);
		}
	}
}

void Game::handleInput(Scene current_scene_)
{
	if(current_scene_ == SCENE_START)
	{
		PSX_ReadPad(&(this->padbuf_one), &(this->padbuf_two));
		if(this->padbuf_one && PAD_START)
		{	
			this->current_level = 1;
			this->current_question = 0;
			this->graphics->loadGameScene(this->current_question);
			this->current_scene = SCENE_GAME;
			SsKeyOn(0);
		}
	}
	
	else if(current_scene_ == SCENE_GAME)
	{
		if(button_timer > 100000)
		{
			PSX_ReadPad(&(this->padbuf_one), &(this->padbuf_two));
			if(this->padbuf_one && this->choice_one == 0)
			{
				if(this->padbuf_one & PAD_TRIANGLE)
					this->choice_one = 1;
				else if(this->padbuf_one & PAD_CIRCLE)
					this->choice_one = 2;
				else if(this->padbuf_one & PAD_CROSS)
					this->choice_one = 3;
				else if(this->padbuf_one & PAD_SQUARE)
					this->choice_one = 4;
			}
		
			else if(this->padbuf_two && this->choice_two == 0)
			{
				if(this->padbuf_two & PAD_TRIANGLE)
					this->choice_two = 1;
				else if(this->padbuf_two & PAD_CIRCLE)
					this->choice_two = 2;
				else if(this->padbuf_two & PAD_CROSS)
					this->choice_two = 3;
				else if(this->padbuf_two & PAD_SQUARE)
					this->choice_two = 4;
			}
		
		}
	
		if(choice_one != 0 && choice_two != 0)
		{
			switch(choice_one)
			{
				case 1:
					player_one_score += questions.p1[this->current_question];
				break;
				case 2:
					player_one_score += questions.p2[this->current_question];
				break;
				case 3:
					player_one_score += questions.p3[this->current_question];
				break;
				case 4:
					player_one_score += questions.p4[this->current_question];
				break;
			}
			
			switch(choice_two)
			{
				case 1:
					player_two_score += questions.p1[this->current_question];
				break;
				case 2:
					player_two_score += questions.p2[this->current_question];
				break;
				case 3:
					player_two_score += questions.p3[this->current_question];
				break;
				case 4:
					player_two_score += questions.p4[this->current_question];
				break;
			}
		
			choice_one = 0;
			choice_two = 0;
			button_timer = 0;
			// change question
			this->current_question++;
			this->graphics->setQuestion(this->current_question);
			if(this->current_question % 3 == 0)
			{
				// sonuc gosterilecek
				this->graphics->setScores(this->player_one_score, this->player_two_score);
				this->result_timer = 0;
				this->current_scene = SCENE_RESULT;
				
				// level degisecek...
				
			}
		}
	}
}

