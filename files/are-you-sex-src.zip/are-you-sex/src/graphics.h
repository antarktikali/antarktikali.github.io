// The class which was supposed to be the graphics class,
// but evolved into something else. hadi bunu da aciklayin yaradiliscilar

#ifndef GRAPHICS_H
#define GRAPHICS_H

extern "C"
{
	#include <psx.h>
	#include <stdlib.h>
	#include <stdio.h>
	#include <string.h>
}
#include "scene.h"
#include "questions.h"

class Graphics
{
	public:
		Graphics();
		void draw(Scene);
		void loadGameScene(int);
		static void vblank_handler();
		static volatile int display_is_old;
		static volatile int time_counter;
		static unsigned int prim_list[0x4000];
		void setScores(int, int);
		void setChoices(int, int);
		void setQuestion(int);
		void drawResultScene();
		
	private:
		SsVag sound;
		void loadAudio();
		int player_one_score;
		int player_two_score;
		
		short choice_one;
		short choice_two;
	
		int dbuf;
		void drawStartScene();
		void loadButtonGraphics();
		void drawGameScene();
		// 256k, dosya okumak icin
		unsigned char data_buffer[0x40000];
		
		// arka plan ve karakter profil resmi
		
		// for some reason a single 320x240 background was fucked up,
		// so we divided it to be smaller than 256 pixels in width.
		GsImage image_bg_l;
		GsSprite sprite_bg_l;
		GsImage image_bg_r;
		GsSprite sprite_bg_r;
		GsImage image_character;
		GsSprite sprite_character;
		
		// tuslar
		GsImage image_triangle;
		GsSprite sprite_triangle;
		GsImage image_circle;
		GsSprite sprite_circle;
		GsImage image_cross;
		GsSprite sprite_cross;
		GsImage image_square;
		GsSprite sprite_square;
		
		// fuck this, fgets() doesn't work?!!?
		Questions questions;
		int current_question;
};

#endif // GRAPHICS_H
