#ifndef SCENE_H
#define SCENE_H

enum Scene
{
	SCENE_START,
	SCENE_GAME,
	SCENE_RESULT
};

#endif // SCENE_H
