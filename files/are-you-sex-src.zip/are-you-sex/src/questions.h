#ifndef QUESTIONS_H
#define QUESTIONS_H

class Questions
{
	// max genislik:
	//"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
	public:
	const char* q1[24] = {
	// lezzbiyenler
	"What word starts with f and ends",
	"What is the opposite of opposite?",
	"Are you going to call us after",
	// abraham
	"What is the meaning of life?",
	"How would you define",
	"What is the difference between",
	// str8 woman
	"Which kind of movies do you like?",
	"What's your favourite sports car?",
	"Who was the first person you",
	// two gay
	"If you were a fish, what kind of",
	"Do you have any hidden talents?",
	"Do you like soccer?",
	// aliyin
	"What is the Einstein's theory of",
	"What am I for you?",
	"Where is crypton?",
	// transabi
	"If you suddenly turn into a woman",
	"What is siren?",
	"What would you buy as a gift?",
	// sr8man
	"Would you bend to get the soap",
	"Do you squeeze the toothpaste",
	"What do you do for fun?",
	// unicorn
	"Why did stock prices fall down?",
	"Have you ever danced under",
	"Do you believe in god?"
	};
	const char* q2[24] = {
	// lezzbiyenler
	"with uck?",
	" ",
	"this conversation?",
	// abraham
	" ",
	"a relationship?",
	"love and romance?",
	// str8 woman
	" ",
	" ",
	"kissed?",
	// two gay
	"fish would you be?",
	" ",
	" ",
	// aliyin
	"general relativity?",
	" ",
	" ",
	// transabi
	"how would you spend your day?",
	" ",
	" ",
	// sr8man
	"on the floor?",
	"from the middle or the end?",
	" ",
	// unicorn
	" ",
	"the moon?",
	" "
	};
	const char* a1[24] = {
	// lezzbiyenler
	"fuck",
	"opposite",
	"we can go out to drink coke",
	// abraham
	"money",
	"nullity",
	"passion",
	// str8 woman
	"horror",
	"bus",
	"a prostitute",
	// two gay
	"shark",
	"I can see under clothes",
	"yeah",
	// aliyin
	"it's about light",
	"an allien",
	"in middle asia",
	// transabi
	"watch my body",
	"a mermaid",
	"parfume",
	// sr8man
	"yes, of course",
	"I don't use it",
	"play this game",
	// unicorn
	"economic crisis",
	"I don't like to dance",
	"that's none of your business"
	};
	const char* a2[24] = {
	// lezzbiyenler
	"firetruck",
	"nothing",
	"yes, of course",
	// abraham
	"tasty kebab and cold shalgam",
	"bliss",
	"emotions and experiences",
	// str8 woman
	"porn",
	"something with horse",
	"babydoll",
	// two gay
	"goldfish",
	"I have a hidden blade",
	"not exactly",
	// aliyin
	"it's about time and space",
	"friend",
	"europe",
	// transabi
	"go shopping",
	"a bird",
	"car",
	// sr8man
	"with pleasure",
	"of course middle",
	"reading",
	// unicorn
	"manipulation",
	"yeah, it was romantic",
	"of course"
	};
	const char* a3[24] = {
	// lezzbiyenler
	"flubberduck",
	"I should think",
	"probably",
	// abraham
	"it's inside the holy book",
	"pain",
	"quality",
	// str8 woman
	"documentary",
	"I don't like them",
	"soap",
	// two gay
	"hamsi",
	"I turn into warewolf at midnight",
	"do you mean football?",
	// aliyin
	"e=mc2",
	"enemy",
	"in U.S.A",
	// transabi
	"have sex with a man",
	"a plane",
	"tie",
	// sr8man
	"hell no",
	"I'm not a person like that",
	"something with myself",
	// unicorn
	"I don't know",
	"nope",
	"absolutely no"
	};
	const char* a4[24] = {
	// lezzbiyenler
	"flying baby ducks",
	"the same",
	"which of you?",
	// abraham
	"sex",
	"routine",
	"range",
	// str8 woman
	"just give me popcorn",
	"you",
	"someone I liked",
	// two gay
	"dolphin",
	"it's a secret",
	"not watching, I like to play",
	// aliyin
	"nice challenge to accept",
	"something to do with it",
	"not here",
	// transabi
	"gossip",
	"something with s...",
	"washing machine",
	// sr8man
	"I feel dirty",
	"I use it normally",
	"walk naked on the street",
	// unicorn
	"game of the U.S.A.",
	"we should do that",
	"there has to be a power"
	};
	const short p1[24] = {
	// lezzbiyenler
	-15,
	0,
	15,
	// abraham
	5,
	-10,
	10,
	// str8 woman
	5,
	-5,
	0,
	// two gay
	5,
	10,
	15,
	// aliyin
	-5,
	-5,
	-10,
	// transabi
	5,
	20,
	15,
	// sr8man
	-5,
	-5,
	20,
	// unicorn
	10,
	-5,
	-15
	};
	const short p2[24] = {
	// lezzbiyenler
	-5,
	-5,
	5,
	// abraham
	20,
	0,
	-5,
	// str8 woman
	15,
	10,
	-5,
	// two gay
	15,
	15,
	5,
	// aliyin
	10,
	5,
	-20,
	// transabi
	10,
	5,
	-5,
	// sr8man
	5,
	10,
	-15,
	// unicorn
	5,
	0,
	-10
	};
	const short p3[24] = {
	// lezzbiyenler
	5,
	-10,
	0,
	// abraham
	-10,
	20,
	20,
	// str8 woman
	-20,
	15,
	10,
	// two gay
	30,
	20,
	-10,
	// aliyin
	0,
	-10,
	-15,
	// transabi
	0,
	-10,
	-10,
	// sr8man
	-10,
	-15,
	5,
	// unicorn
	0,
	-10,
	5
	};
	const short p4[24] = {
	// lezzbiyenler
	15,
	15,
	-15,
	// abraham
	10,
	-5,
	-10,
	// str8 woman
	0,
	0,
	-10,
	// two gay
	-5,
	-20,
	20,
	// aliyin
	5,
	15,
	10,
	// transabi
	-10,
	-5,
	5,
	// sr8man
	15,
	0,
	15,
	// unicorn
	-10,
	10,
	15
	};
	
	const char* gfx_bl[8] = {
	"cdrom:\\LEZ_L.TIM;1",
	"cdrom:\\IBO_L.TIM;1",
	"cdrom:\\SWMN_L.TIM;1",
	"cdrom:\\GAY_L.TIM;1",
	"cdrom:\\ALIEN_L.TIM;1",
	"cdrom:\\TRANS_L.TIM;1",
	"cdrom:\\SMAN_L.TIM;1",
	"cdrom:\\UZAY_L.TIM;1"
	};
	
	const char* gfx_br[8] = {
	"cdrom:\\LEZ_R.TIM;1",
	"cdrom:\\IBO_R.TIM;1",
	"cdrom:\\SWMN_R.TIM;1",
	"cdrom:\\GAY_R.TIM;1",
	"cdrom:\\ALIEN_R.TIM;1",
	"cdrom:\\TRANS_R.TIM;1",
	"cdrom:\\SMAN_R.TIM;1",
	"cdrom:\\UZAY_R.TIM;1"
	};
	
	const char* gfx_char[8] = {
	"cdrom:\\GIRLS.TIM;1",
	"cdrom:\\ABRA.TIM;1",
	"cdrom:\\SWOMN.TIM;1",
	"cdrom:\\GAY.TIM;1",
	"cdrom:\\ALIEN.TIM;1",
	"cdrom:\\TRANS.TIM;1",
	"cdrom:\\STRMN.TIM;1",
	"cdrom:\\AT.TIM;1"
	};
};

#endif // QUESTIONS_H
