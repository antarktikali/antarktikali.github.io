#include "game.h"

int main() {
	Game* g = new Game();
    return 0; // never reaches this anyway :P
}
