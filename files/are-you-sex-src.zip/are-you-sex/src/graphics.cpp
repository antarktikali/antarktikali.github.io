#include "graphics.h"
#include "game.h"
#include "questions.h"

volatile int Graphics::display_is_old = 1;
volatile int Graphics::time_counter = 0;
unsigned int Graphics::prim_list[0x4000];

Graphics::Graphics()
{
	PSX_Init();
	GsInit();
    GsSetList(Graphics::prim_list);
    GsClearMem();
    
    SsInit();
    //SsWait();
    
    choice_one = 0;
    choice_two = 0;

	/* Here you set screen resolution of your game and video mode */
	GsSetVideoMode(320, 240, VMODE_PAL);

	/* you need to load font if you want to use GsPrintFont function */
	GsLoadFont(960, 0, 960, 128);
	
	this->dbuf = 0;
	
	SetVBlankHandler(Graphics::vblank_handler);
	
	this->loadButtonGraphics();
	this->loadAudio();
}

void Graphics::loadAudio()
{
	FILE *a = fopen("cdrom:MUSIC.RAW;1", "rb");
    fseek(a, 0, SEEK_END);
    int asize = ftell(a);
    fseek(a, 0, SEEK_SET);
    
    fread(data_buffer, sizeof(char), asize, a);
    fclose(a);
    SsUpload(data_buffer, asize, SPU_DATA_BASE_ADDR);
	
	SsVoiceStartAddr(0, SPU_DATA_BASE_ADDR);
	
	SsVoiceVol(0, 0x3fff, 0x3fff);
	
//	SsVoicePitch(0, 0x1000 / (44100 / 11025));
	SsVoicePitch(0, 0x1000 / 6);
}

void Graphics::loadButtonGraphics()
{
	FILE *f = fopen("cdrom:\\TRIANGLE.TIM;1", "rb");
    fseek(f, 0, SEEK_END);
    int fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    fread(this->data_buffer, sizeof(char), fsize, f);
    fclose(f);
    
    GsImageFromTim(&(this->image_triangle), this->data_buffer);
    GsUploadImage(&(this->image_triangle));
    GsSpriteFromImage(&(this->sprite_triangle), &(this->image_triangle), 1);
    
    f = fopen("cdrom:\\CIRCLE.TIM;1", "rb");
    fseek(f, 0, SEEK_END);
    fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    fread(this->data_buffer, sizeof(char), fsize, f);
    fclose(f);
    
    GsImageFromTim(&(this->image_circle), this->data_buffer);
    GsUploadImage(&(this->image_circle));
    GsSpriteFromImage(&(this->sprite_circle), &(this->image_circle), 1);
    
    f = fopen("cdrom:\\CROSS.TIM;1", "rb");
    fseek(f, 0, SEEK_END);
    fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    fread(this->data_buffer, sizeof(char), fsize, f);
    fclose(f);
    
    GsImageFromTim(&(this->image_cross), this->data_buffer);
    GsUploadImage(&(this->image_cross));
    GsSpriteFromImage(&(this->sprite_cross), &(this->image_cross), 1);
    
    f = fopen("cdrom:\\SQUARE.TIM;1", "rb");
    fseek(f, 0, SEEK_END);
    fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    fread(this->data_buffer, sizeof(char), fsize, f);
    fclose(f);
    
    GsImageFromTim(&(this->image_square), this->data_buffer);
    GsUploadImage(&(this->image_square));
    GsSpriteFromImage(&(this->sprite_square), &(this->image_square), 1);
}

void Graphics::setScores(int pone_, int ptwo_)
{
	this->player_one_score = pone_;
	this->player_two_score = ptwo_;
}

void Graphics::setChoices(int cone_, int ctwo_)
{
	this->choice_one = cone_;
	this->choice_two = ctwo_;
}

void Graphics::draw(Scene current_scene_)
{
	/* here we check if image was sent to TV */
	/* if sent - we start drawing again */
	if(Graphics::display_is_old)
	{
		/* changing flag of */
		this->dbuf =!(this->dbuf);

		/* here we switch drawing area and display area */
		GsSetDispEnvSimple(0, this->dbuf ? 0 : 256);
		GsSetDrawEnvSimple(0, this->dbuf ? 256 : 0, 320, 240);

		/* clear drawing area */
		GsSortCls(0,0,0);

		switch(current_scene_)
		{
		case SCENE_START:
			drawStartScene();
			break;
		case SCENE_GAME:
			drawGameScene();
			break;
		case SCENE_RESULT:
			drawResultScene();
			break;
		}

		GsDrawList();
		while(GsIsDrawing());

		/* set flag to prevent redrawing until drawed picture will be sent on TV */
		display_is_old=0;
	}
}

void Graphics::loadGameScene(int current_level_)
{
	GsClearMem();
	
	GsLoadFont(960, 0, 960, 128);
	this->loadButtonGraphics();

	char gfx_bl[64];
	strcpy(gfx_bl, questions.gfx_bl[current_question/3]);
	FILE *f = fopen(gfx_bl, "rb");
    fseek(f, 0, SEEK_END);
    int fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    fread(this->data_buffer, sizeof(char), fsize, f);
    fclose(f);
    
    GsImageFromTim(&(this->image_bg_l), this->data_buffer);
    GsUploadImage(&(this->image_bg_l));
    GsSpriteFromImage(&(this->sprite_bg_l), &(this->image_bg_l), 1);
    
    char gfx_br[64];
	strcpy(gfx_br, questions.gfx_br[current_question/3]);
    f = fopen(gfx_br, "rb");
    fseek(f, 0, SEEK_END);
    fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    fread(this->data_buffer, sizeof(char), fsize, f);
    fclose(f);
    
    GsImageFromTim(&(this->image_bg_r), this->data_buffer);
    GsUploadImage(&(this->image_bg_r));
    GsSpriteFromImage(&(this->sprite_bg_r), &(this->image_bg_r), 1);
    
    char gfx_char[64];
	strcpy(gfx_char, questions.gfx_char[current_question/3]);
   	f = fopen(gfx_char, "rb");
    fseek(f, 0, SEEK_END);
    fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    fread(this->data_buffer, sizeof(char), fsize, f);
    fclose(f);
    
    GsImageFromTim(&(this->image_character), this->data_buffer);
    GsUploadImage(&(this->image_character));
    GsSpriteFromImage(&(this->sprite_character), &(this->image_character), 1);
}

void Graphics::drawStartScene()
{
	GsSortCls(200,0,0);
	GsPrintFont(90, 210, "Press START to play the game");
}

void Graphics::setQuestion(int question_)
{
	this->current_question = question_;
}

void Graphics::drawResultScene()
{
	// Background
	this->sprite_bg_l.x = 0; this->sprite_bg_l.y = 0;
	this->sprite_bg_l.w = 160; this->sprite_bg_l.h = 240;
	GsSortSprite(&(this->sprite_bg_l));
	
	this->sprite_bg_r.x = 160; this->sprite_bg_r.y = 0;
	this->sprite_bg_r.w = 160; this->sprite_bg_r.h = 240;
	GsSortSprite(&(this->sprite_bg_r));
	
	// Character
	this->sprite_character.x = 112; this->sprite_character.y = 10;
	this->sprite_character.w = 96; this->sprite_character.h = 128;
	GsSortSprite(&(this->sprite_character));
	
	// skorlari yazdiralim...
	// TODO skorlari al!
	char* score_buff_one;
	char* score_buff_two;
	itoa(this->player_one_score, score_buff_one, 10);
	GsPrintFont(10, 10, score_buff_one);
	itoa(this->player_two_score, score_buff_two, 10);
	GsPrintFont(290, 10, score_buff_two);
	// soruyu yazalim...
	if(this->player_one_score > this->player_two_score)
	{
		GsPrintFont(20, 145, "Player one got the date!");
		GsPrintFont(20, 155, "Player two, what you gonna do now?");
	}
	else if (this->player_two_score > this->player_one_score)
	{
		GsPrintFont(20, 145, "Player two got the date!");
		GsPrintFont(20, 155, "Player one, what you gonna do now?");
	}
	else
	{
		GsPrintFont(20, 145, "Both players got the date!");
		GsPrintFont(20, 155, "(if you know what I mean ;))");
	}
}

void Graphics::drawGameScene()
{
	// Background
	this->sprite_bg_l.x = 0; this->sprite_bg_l.y = 0;
	this->sprite_bg_l.w = 160; this->sprite_bg_l.h = 240;
	GsSortSprite(&(this->sprite_bg_l));
	
	this->sprite_bg_r.x = 160; this->sprite_bg_r.y = 0;
	this->sprite_bg_r.w = 160; this->sprite_bg_r.h = 240;
	GsSortSprite(&(this->sprite_bg_r));
	
	// Character
	this->sprite_character.x = 112; this->sprite_character.y = 10;
	this->sprite_character.w = 96; this->sprite_character.h = 128;
	GsSortSprite(&(this->sprite_character));
	
	// skorlari yazdiralim...
	// TODO skorlari al!
	char* score_buff_one;
	char* score_buff_two;
	itoa(this->player_one_score, score_buff_one, 10);
	GsPrintFont(10, 10, score_buff_one);
	itoa(this->player_two_score, score_buff_two, 10);
	GsPrintFont(290, 10, score_buff_two);
	// soruyu yazalim...
	GsPrintFont(20, 145, questions.q1[this->current_question]);
	GsPrintFont(20, 155, questions.q2[this->current_question]);
	
	GsLine line;
    line.r = 255; line.g = 255; line.b = 255;
    line.x[0] = 10; line.y[0] = 165;
    line.x[1] = 310; line.y[1] = 165;
    line.attribute = 0;
    GsSortLine(&line);
    
    // cevaplari yazalim...
    if(choice_one == 1 || choice_one == 0)
    {
		this->sprite_triangle.x = 10; this->sprite_triangle.y = 170;
		this->sprite_triangle.w = 16; this->sprite_triangle.h = 16;
		GsSortSprite(&(this->sprite_triangle));
	}
	if(choice_two == 1 || choice_two == 0)
	{
		this->sprite_triangle.x = 294; this->sprite_triangle.y = 170;
		this->sprite_triangle.w = 16; this->sprite_triangle.h = 16;
		GsSortSprite(&(this->sprite_triangle));
	}
	GsPrintFont(30, 170, questions.a1[this->current_question]);
	
	if(choice_one == 2 || choice_one == 0)
    {
		this->sprite_circle.x = 10; this->sprite_circle.y = 170 + 16;
		this->sprite_circle.w = 16; this->sprite_circle.h = 16;
		GsSortSprite(&(this->sprite_circle));
	}
	if(choice_two == 2 || choice_two == 0)
	{
		this->sprite_circle.x = 294; this->sprite_circle.y = 170 + 16;
		this->sprite_circle.w = 16; this->sprite_circle.h = 16;
		GsSortSprite(&(this->sprite_circle));
	}
	GsPrintFont(30, 170 + 16, questions.a2[this->current_question]);
	
	if(choice_one == 3 || choice_one == 0)
    {
		this->sprite_cross.x = 10; this->sprite_cross.y = 170 + 32;
		this->sprite_cross.w = 16; this->sprite_cross.h = 16;
		GsSortSprite(&(this->sprite_cross));
	}
	if(choice_two == 3 || choice_two == 0)
	{
		this->sprite_cross.x = 294; this->sprite_cross.y = 170 + 32;
		this->sprite_cross.w = 16; this->sprite_cross.h = 16;
		GsSortSprite(&(this->sprite_cross));
	}
	GsPrintFont(30, 170 + 32, questions.a3[this->current_question]);
	
	if(choice_one == 4 || choice_one == 0)
    {
		this->sprite_square.x = 10; this->sprite_square.y = 170 + 48;
		this->sprite_square.w = 16; this->sprite_square.h = 16;
		GsSortSprite(&(this->sprite_square));
	}
	if(choice_two == 4 || choice_two == 0)
	{
		this->sprite_square.x = 294; this->sprite_square.y = 170 + 48;
		this->sprite_square.w = 16; this->sprite_square.h = 16;
		GsSortSprite(&(this->sprite_square));	
	}
	GsPrintFont(30, 170 + 48, questions.a4[this->current_question]);
	
}

void Graphics::vblank_handler()
{
    Graphics::display_is_old = 1;
    Graphics::time_counter++;
}
