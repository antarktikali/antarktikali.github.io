#ifndef GAME_H
#define GAME_H

extern "C"
{
	#include <psx.h>
	#include <stdlib.h>
	#include <stdio.h>
	#include <string.h>
}

#include "graphics.h"
#include "scene.h"

class Game
{
	protected:
		
	public:
		Game();
		int getPlayerOneScore();
		int getPlayerTwoScore();
	private:
	
		int player_one_score;
		int player_two_score;
		unsigned short padbuf_one;
		unsigned short padbuf_two;
		short choice_one;
		short choice_two;
		
		Questions questions;
		
		int result_timer;
		int button_timer;
		Scene current_scene;
		int current_question;
		int current_level;
		Graphics* graphics;
		bool isRunning;
		void mainLoop();
		void handleInput(Scene);
		
		void loadQuestions(int);
		char txt_question_first[40];
		char txt_question_second[40];
		char txt_answer_one[40];
		char txt_answer_two[40];
		char txt_answer_three[40];
		char txt_answer_four[40];
};

#endif // GAME_H
